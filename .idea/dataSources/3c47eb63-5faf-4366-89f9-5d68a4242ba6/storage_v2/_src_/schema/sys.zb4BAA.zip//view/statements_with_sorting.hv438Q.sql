create definer = root@localhost view statements_with_sorting as
select 1 AS `query`,
       1 AS `db`,
       1 AS `exec_count`,
       1 AS `total_latency`,
       1 AS `sort_merge_passes`,
       1 AS `avg_sort_merges`,
       1 AS `sorts_using_scans`,
       1 AS `sort_using_range`,
       1 AS `rows_sorted`,
       1 AS `avg_rows_sorted`,
       1 AS `first_seen`,
       1 AS `last_seen`,
       1 AS `digest`;

