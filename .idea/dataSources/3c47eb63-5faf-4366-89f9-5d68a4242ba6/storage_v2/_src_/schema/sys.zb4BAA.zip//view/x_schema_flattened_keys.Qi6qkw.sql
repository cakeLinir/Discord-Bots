create definer = root@localhost view x$schema_flattened_keys as
select 1 AS `table_schema`,
       1 AS `table_name`,
       1 AS `index_name`,
       1 AS `non_unique`,
       1 AS `subpart_exists`,
       1 AS `index_columns`;

