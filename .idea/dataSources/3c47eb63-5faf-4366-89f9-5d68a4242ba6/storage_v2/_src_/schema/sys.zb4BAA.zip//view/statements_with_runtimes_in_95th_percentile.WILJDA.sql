create definer = root@localhost view statements_with_runtimes_in_95th_percentile as
select 1 AS `query`,
       1 AS `db`,
       1 AS `full_scan`,
       1 AS `exec_count`,
       1 AS `err_count`,
       1 AS `warn_count`,
       1 AS `total_latency`,
       1 AS `max_latency`,
       1 AS `avg_latency`,
       1 AS `rows_sent`,
       1 AS `rows_sent_avg`,
       1 AS `rows_examined`,
       1 AS `rows_examined_avg`,
       1 AS `first_seen`,
       1 AS `last_seen`,
       1 AS `digest`;

