create definer = root@localhost view x$host_summary_by_file_io_type as
select 1 AS `host`, 1 AS `event_name`, 1 AS `total`, 1 AS `total_latency`, 1 AS `max_latency`;

