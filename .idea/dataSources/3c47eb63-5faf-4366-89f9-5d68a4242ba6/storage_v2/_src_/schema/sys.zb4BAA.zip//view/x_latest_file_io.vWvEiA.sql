create definer = root@localhost view x$latest_file_io as
select 1 AS `thread`, 1 AS `file`, 1 AS `latency`, 1 AS `operation`, 1 AS `requested`;

