create definer = root@localhost view x$ps_digest_avg_latency_distribution as
select 1 AS `cnt`, 1 AS `avg_us`;

