create definer = root@localhost view x$host_summary_by_statement_type as
select 1 AS `host`,
       1 AS `statement`,
       1 AS `total`,
       1 AS `total_latency`,
       1 AS `max_latency`,
       1 AS `lock_latency`,
       1 AS `cpu_latency`,
       1 AS `rows_sent`,
       1 AS `rows_examined`,
       1 AS `rows_affected`,
       1 AS `full_scans`;

