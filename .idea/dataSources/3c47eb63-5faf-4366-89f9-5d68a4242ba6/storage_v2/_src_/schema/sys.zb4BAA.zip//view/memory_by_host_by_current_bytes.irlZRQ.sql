create definer = root@localhost view memory_by_host_by_current_bytes as
select 1 AS `host`,
       1 AS `current_count_used`,
       1 AS `current_allocated`,
       1 AS `current_avg_alloc`,
       1 AS `current_max_alloc`,
       1 AS `total_allocated`;

