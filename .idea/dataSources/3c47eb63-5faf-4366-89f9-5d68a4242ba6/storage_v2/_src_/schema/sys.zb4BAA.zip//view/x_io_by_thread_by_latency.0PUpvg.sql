create definer = root@localhost view x$io_by_thread_by_latency as
select 1 AS `user`,
       1 AS `total`,
       1 AS `total_latency`,
       1 AS `min_latency`,
       1 AS `avg_latency`,
       1 AS `max_latency`,
       1 AS `thread_id`,
       1 AS `processlist_id`;

