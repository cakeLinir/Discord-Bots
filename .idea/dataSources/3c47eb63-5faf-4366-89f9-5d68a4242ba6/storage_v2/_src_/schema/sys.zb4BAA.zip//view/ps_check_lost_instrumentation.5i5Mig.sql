create definer = root@localhost view ps_check_lost_instrumentation as
select 1 AS `variable_name`, 1 AS `variable_value`;

