create definer = root@localhost view schema_unused_indexes as
select 1 AS `object_schema`, 1 AS `object_name`, 1 AS `index_name`;

