create definer = root@localhost view user_summary_by_file_io_type as
select 1 AS `user`, 1 AS `event_name`, 1 AS `total`, 1 AS `latency`, 1 AS `max_latency`;

