create definer = root@localhost view schema_redundant_indexes as
select 1 AS `table_schema`,
       1 AS `table_name`,
       1 AS `redundant_index_name`,
       1 AS `redundant_index_columns`,
       1 AS `redundant_index_non_unique`,
       1 AS `dominant_index_name`,
       1 AS `dominant_index_columns`,
       1 AS `dominant_index_non_unique`,
       1 AS `subpart_exists`,
       1 AS `sql_drop_index`;

