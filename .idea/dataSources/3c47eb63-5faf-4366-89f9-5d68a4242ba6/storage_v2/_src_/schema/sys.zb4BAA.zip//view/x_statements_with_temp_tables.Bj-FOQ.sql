create definer = root@localhost view x$statements_with_temp_tables as
select 1 AS `query`,
       1 AS `db`,
       1 AS `exec_count`,
       1 AS `total_latency`,
       1 AS `memory_tmp_tables`,
       1 AS `disk_tmp_tables`,
       1 AS `avg_tmp_tables_per_query`,
       1 AS `tmp_tables_to_disk_pct`,
       1 AS `first_seen`,
       1 AS `last_seen`,
       1 AS `digest`;

