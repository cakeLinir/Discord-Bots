create definer = root@localhost view x$innodb_buffer_stats_by_schema as
select 1 AS `object_schema`,
       1 AS `allocated`,
       1 AS `data`,
       1 AS `pages`,
       1 AS `pages_hashed`,
       1 AS `pages_old`,
       1 AS `rows_cached`;

