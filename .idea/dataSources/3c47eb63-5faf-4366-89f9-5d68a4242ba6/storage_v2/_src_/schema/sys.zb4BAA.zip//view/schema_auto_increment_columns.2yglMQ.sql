create definer = root@localhost view schema_auto_increment_columns as
select 1 AS `table_schema`,
       1 AS `table_name`,
       1 AS `column_name`,
       1 AS `data_type`,
       1 AS `column_type`,
       1 AS `is_signed`,
       1 AS `is_unsigned`,
       1 AS `max_value`,
       1 AS `auto_increment`,
       1 AS `auto_increment_ratio`;

