create definer = root@localhost view x$ps_schema_table_statistics_io as
select 1 AS `table_schema`,
       1 AS `table_name`,
       1 AS `count_read`,
       1 AS `sum_number_of_bytes_read`,
       1 AS `sum_timer_read`,
       1 AS `count_write`,
       1 AS `sum_number_of_bytes_write`,
       1 AS `sum_timer_write`,
       1 AS `count_misc`,
       1 AS `sum_timer_misc`;

