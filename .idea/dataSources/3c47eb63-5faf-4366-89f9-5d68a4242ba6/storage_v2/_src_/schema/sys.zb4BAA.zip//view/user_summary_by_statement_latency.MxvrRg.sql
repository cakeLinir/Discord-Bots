create definer = root@localhost view user_summary_by_statement_latency as
select 1 AS `user`,
       1 AS `total`,
       1 AS `total_latency`,
       1 AS `max_latency`,
       1 AS `lock_latency`,
       1 AS `cpu_latency`,
       1 AS `rows_sent`,
       1 AS `rows_examined`,
       1 AS `rows_affected`,
       1 AS `full_scans`;

