create definer = root@localhost view x$waits_by_host_by_latency as
select 1 AS `host`, 1 AS `event`, 1 AS `total`, 1 AS `total_latency`, 1 AS `avg_latency`, 1 AS `max_latency`;

