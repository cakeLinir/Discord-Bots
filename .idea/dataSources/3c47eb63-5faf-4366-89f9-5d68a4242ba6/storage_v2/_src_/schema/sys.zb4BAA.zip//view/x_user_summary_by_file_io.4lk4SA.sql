create definer = root@localhost view x$user_summary_by_file_io as
select 1 AS `user`, 1 AS `ios`, 1 AS `io_latency`;

