create definer = root@localhost view x$statements_with_full_table_scans as
select 1 AS `query`,
       1 AS `db`,
       1 AS `exec_count`,
       1 AS `total_latency`,
       1 AS `no_index_used_count`,
       1 AS `no_good_index_used_count`,
       1 AS `no_index_used_pct`,
       1 AS `rows_sent`,
       1 AS `rows_examined`,
       1 AS `rows_sent_avg`,
       1 AS `rows_examined_avg`,
       1 AS `first_seen`,
       1 AS `last_seen`,
       1 AS `digest`;

