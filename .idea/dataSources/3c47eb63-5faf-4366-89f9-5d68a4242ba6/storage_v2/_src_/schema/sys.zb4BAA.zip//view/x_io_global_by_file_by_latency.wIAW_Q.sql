create definer = root@localhost view x$io_global_by_file_by_latency as
select 1 AS `file`,
       1 AS `total`,
       1 AS `total_latency`,
       1 AS `count_read`,
       1 AS `read_latency`,
       1 AS `count_write`,
       1 AS `write_latency`,
       1 AS `count_misc`,
       1 AS `misc_latency`;

