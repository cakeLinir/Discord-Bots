create definer = root@localhost view version as
select 1 AS `sys_version`, 1 AS `mysql_version`;

