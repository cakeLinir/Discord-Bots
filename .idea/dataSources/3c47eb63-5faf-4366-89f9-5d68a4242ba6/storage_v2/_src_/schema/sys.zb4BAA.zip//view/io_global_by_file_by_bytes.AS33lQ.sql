create definer = root@localhost view io_global_by_file_by_bytes as
select 1 AS `file`,
       1 AS `count_read`,
       1 AS `total_read`,
       1 AS `avg_read`,
       1 AS `count_write`,
       1 AS `total_written`,
       1 AS `avg_write`,
       1 AS `total`,
       1 AS `write_pct`;

