create definer = root@localhost view x$ps_digest_95th_percentile_by_avg_us as
select 1 AS `avg_us`, 1 AS `percentile`;

