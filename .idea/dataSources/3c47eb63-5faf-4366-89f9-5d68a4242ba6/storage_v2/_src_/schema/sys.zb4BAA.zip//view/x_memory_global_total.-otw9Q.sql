create definer = root@localhost view x$memory_global_total as
select 1 AS `total_allocated`;

