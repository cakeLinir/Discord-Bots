create definer = root@localhost view x$memory_global_by_current_bytes as
select 1 AS `event_name`,
       1 AS `current_count`,
       1 AS `current_alloc`,
       1 AS `current_avg_alloc`,
       1 AS `high_count`,
       1 AS `high_alloc`,
       1 AS `high_avg_alloc`;

