create definer = root@localhost view x$schema_index_statistics as
select 1 AS `table_schema`,
       1 AS `table_name`,
       1 AS `index_name`,
       1 AS `rows_selected`,
       1 AS `select_latency`,
       1 AS `rows_inserted`,
       1 AS `insert_latency`,
       1 AS `rows_updated`,
       1 AS `update_latency`,
       1 AS `rows_deleted`,
       1 AS `delete_latency`;

