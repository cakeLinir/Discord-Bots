create definer = root@localhost view x$statements_with_errors_or_warnings as
select 1 AS `query`,
       1 AS `db`,
       1 AS `exec_count`,
       1 AS `errors`,
       1 AS `error_pct`,
       1 AS `warnings`,
       1 AS `warning_pct`,
       1 AS `first_seen`,
       1 AS `last_seen`,
       1 AS `digest`;

