create definer = root@localhost view x$user_summary_by_stages as
select 1 AS `user`, 1 AS `event_name`, 1 AS `total`, 1 AS `total_latency`, 1 AS `avg_latency`;

