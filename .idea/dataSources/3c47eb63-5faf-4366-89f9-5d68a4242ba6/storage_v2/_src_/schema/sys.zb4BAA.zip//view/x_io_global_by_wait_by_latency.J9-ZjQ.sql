create definer = root@localhost view x$io_global_by_wait_by_latency as
select 1 AS `event_name`,
       1 AS `total`,
       1 AS `total_latency`,
       1 AS `avg_latency`,
       1 AS `max_latency`,
       1 AS `read_latency`,
       1 AS `write_latency`,
       1 AS `misc_latency`,
       1 AS `count_read`,
       1 AS `total_read`,
       1 AS `avg_read`,
       1 AS `count_write`,
       1 AS `total_written`,
       1 AS `avg_written`;

