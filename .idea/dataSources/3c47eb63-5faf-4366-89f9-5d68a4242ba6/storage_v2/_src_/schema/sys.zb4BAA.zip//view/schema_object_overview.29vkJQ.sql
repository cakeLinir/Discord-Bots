create definer = root@localhost view schema_object_overview as
select 1 AS `db`, 1 AS `object_type`, 1 AS `count`;

