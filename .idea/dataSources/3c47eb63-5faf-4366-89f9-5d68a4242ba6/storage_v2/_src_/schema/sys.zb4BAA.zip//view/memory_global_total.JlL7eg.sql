create definer = root@localhost view memory_global_total as
select 1 AS `total_allocated`;

