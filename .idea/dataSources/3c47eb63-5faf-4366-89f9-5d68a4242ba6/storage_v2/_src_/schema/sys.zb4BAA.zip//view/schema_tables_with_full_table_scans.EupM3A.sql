create definer = root@localhost view schema_tables_with_full_table_scans as
select 1 AS `object_schema`, 1 AS `object_name`, 1 AS `rows_full_scanned`, 1 AS `latency`;

