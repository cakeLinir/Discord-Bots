create definer = root@localhost view session_ssl_status as
select 1 AS `thread_id`, 1 AS `ssl_version`, 1 AS `ssl_cipher`, 1 AS `ssl_sessions_reused`;

