create definer = root@localhost view metrics as
select 1 AS `Variable_name`, 1 AS `Variable_value`, 1 AS `Type`, 1 AS `Enabled`;

