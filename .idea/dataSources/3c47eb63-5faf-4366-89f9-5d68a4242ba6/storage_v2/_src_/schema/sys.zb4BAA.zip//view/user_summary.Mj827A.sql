create definer = root@localhost view user_summary as
select 1 AS `user`,
       1 AS `statements`,
       1 AS `statement_latency`,
       1 AS `statement_avg_latency`,
       1 AS `table_scans`,
       1 AS `file_ios`,
       1 AS `file_io_latency`,
       1 AS `current_connections`,
       1 AS `total_connections`,
       1 AS `unique_hosts`,
       1 AS `current_memory`,
       1 AS `total_memory_allocated`;

