create definer = root@localhost view x$waits_global_by_latency as
select 1 AS `events`, 1 AS `total`, 1 AS `total_latency`, 1 AS `avg_latency`, 1 AS `max_latency`;

